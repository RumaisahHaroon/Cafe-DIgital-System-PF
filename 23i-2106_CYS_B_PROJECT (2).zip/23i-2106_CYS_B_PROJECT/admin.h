#ifndef ADMIN_H
#define ADMIN_H
#include "admin.cpp"
void admin();
void stock();
void credentials();
void noti();
void timeorder();
void viewcomplains();




#endif
