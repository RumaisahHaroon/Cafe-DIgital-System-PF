#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include "employee.cpp"
void employee();
void order();
void notifi();
void stocksearch();


#endif
