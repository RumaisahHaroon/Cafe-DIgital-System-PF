#ifndef EMPLOYEE_H
#define EMPLOYEE_H

void bubbleSort(char item[][10], double Price[], int No_Items[], int itemCount) {
    for (int i = 0; i < itemCount - 1; i++) {
        for (int j = 0; j < itemCount - i - 1; j++) {
            if (strcmp(item[j], item[j + 1]) > 0) {
                swap(item[j], item[j + 1]);
                swap(Price[j], Price[j + 1]);
                swap(No_Items[j], No_Items[j + 1]);
            }
        }
    }
}



void order()
{
char head[30], item[5][10];
    double Price[5];
    int No_Items[5];
    int i = 0;
    int itemCount = 0; // Initialize itemCount

    fstream fs("stock.txt", ios::in);

    if (!fs) 
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } 
    else 
    
    {
        cout << "\nFile Found Congrats";
        fs.getline(head, 30, '\n');
        while (fs.getline(item[i], 10, ' ') && fs >> Price[i] >> No_Items[i]) 
        {
            fs.ignore();
            i++;
        }

        itemCount = i; // Set itemCount after reading the data
        fs.close();   // Close the file after reading

        // Perform bubble sort
        bubbleSort(item, Price, No_Items, itemCount);
    }

    // Print sorted data from arrays on screen
    //cout << "\nData read from file in arrays ::: \n";
    //cout << "\n" << head << endl;
    //for (int k = 0; k < i; k++) {
      //  cout << left << setw(15) << item[k] << setw(10) << Price[k] << setw(10) << No_Items[k] << endl;
    //}
     //////////////////////////////////////////////////////// Order food
    char choiceitem[50],NAME[50],numb[50];
    int choice, orderquantity, ordercount,id;
    
    cout<<"Is the customer\n1.Staff memeber\n2. Student\n";
    cin>>id;
     if (id==1)
     {
           cout<<"Enter name of the staff member:";
           cin.ignore();
           cin.getline(NAME,50);
           cout<<"Enter id number::";
           cin.ignore();
           cin.getline(numb,50);
     }
     else
     {
           cout<<"Enter name of the student:";
           cin.ignore();
           cin.getline(NAME,50);
           cout<<"Enter roll number::";
           cin.ignore();
           cin.getline(numb,50);
     }
     
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);   
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

    

   /* if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;

        // Calculate the price
        double total_price = orderquantity * Price[choice - 1];

        // Update stock
        No_Items[choice - 1] -= orderquantity;

        // Write order details to the file
        ofstream order("order.txt", ios::app);
         if (id==1)
         {
          order<<"****STAFF****"<<endl;
          order<<"NAME: "<<NAME<<"      ID NUMBER: "<<numb<<endl;
          order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
          order.close();
         }
         else
         {
          order<<"****STUDENT****"<<endl;
          order<<"NAME: "<<NAME<<"      ROLL NUMBER: "<<numb<<endl;
          order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
          order.close();
         }
        
        ///update stock.txt with new data
        ofstream stock("stock.txt");
        stock << head << endl;
        for (int k = 0; k < i; k++)
        {
           
            stock << item[k] << " " << Price[k] << " " << No_Items[k] << endl;
        }
        stock.close();

        cout << "Order placed successfully." << endl;
        cout << "\n------ Digital Slip ------\n";
        cout << "Item: " << choiceitem << "\n";
        cout << "Quantity: " << orderquantity << "\n";
        cout << "Total: $" << total_price << "\n";
        cout << "--------------------------\n";
    }
    else
    {
        cout << "Invalid choice." << endl;
    }*/
    
    if (choice >= 1 && choice <= 10)
{
    cout << "Enter the quantity: ";
    cin >> orderquantity;

    // Calculate the price using Price[choice]
    double total_price = orderquantity * Price[choice];

    // Update stock
    No_Items[choice] -= orderquantity;

    // Write order details to the file
    ofstream order("order.txt", ios::app);
    // ... (rest of the code)

    // Update stock.txt with new data
    ofstream stock("stock.txt");
    stock << head << endl;
    for (int k = 0; k < i; k++)
    {
        stock << item[k] << " " << Price[k] << " " << No_Items[k] << endl;
    }
    stock.close();

    cout << "Order placed successfully." << endl;
    cout << "\n------ Digital Slip ------\n";
    cout << "Item: " << choiceitem << "\n";
    cout << "Quantity: " << orderquantity << "\n";
    cout << "Total: $" << total_price << "\n";
    cout << "--------------------------\n";
}

    
}


void notifi()
{
    ifstream noti("notifications.txt");
    if (noti.is_open()) {
        cout << "Notifications:\n";
        
        char notification[100];
        while (noti.getline(notification, 100)) {
            cout << notification <<endl;
        }
        noti.close();
    } else {
        cout << "Error opening notifications file." << endl;
    }
}
  
  
  
  
  
void stocksearch()
{
 char head[30], item[5][10];
	double Price[5];
	int No_Items[5];
	int i=0;
	fstream fs("stock.txt",ios::in);
               fs.getline(head,30,'\n');
		while(fs.getline(item[i],10,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}
	fs.close();
	
	
  char tobefound[50];
   int flag=0;
    cin.ignore();  // Clear the input buffer
    cout << "Enter the item name to search: ";
    cin.getline(tobefound,50);
    
      for ( int i = 0; i < 10; ++i) {
          if (strcmp(item[i],tobefound) == 0) 
           {          
            flag=1;
            break;
           }
         }
      if (flag==1)
      {
       cout<<"ITEM FOUND"<<endl;
      }
      else
      {
       cout<<"ITEM NOT FOUND"<<endl;
      }
}  




void employee()
{
    int login = 0;
    do {
        char head[30], emp[5][10];
        int Pass[5];

        int i = 0;

        char enteredUsername[50];
        char enteredPassword[50];

        cout << "Enter username: ";
        cin >> enteredUsername;

        cout << "Enter password: ";
        cin >> enteredPassword;

        fstream fs("emp.txt", ios::in);

        if (!fs) {
            cout << "\nFile not found\n";
            cout << "\nCheck file name\n";
        } else {
            cout << "\nFile Found Congrats\n";
            fs.getline(head, 30, '\n');
            while (fs.getline(emp[i], 10, ' '), fs >> Pass[i]) {
                fs.ignore();
                i++;
            }
        }

        fs.close();

        login = 0;  // Reset login status

        for (int j = 0; j < i; j++) {
            if ((strcmp(emp[j], enteredUsername) == 0) && (Pass[j] == atoi(enteredPassword))) {
                cout << "\n\nLOGIN SUCCESSFUL\n\n";
                login = 1;
                break;  // Exit the loop if a match is found
            }
        }

        if (login == 0) {
            cout << "WRONG USERNAME OR PASSWORD\n\n";
        }

    } while (login == 0);
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///after login
char choice;
  cout<<"Select the desired option\n1.Take order\n2.View Notifications\n3.Search stock\n";
 cin>>choice;
 
 switch(choice)
 {
  case'1':
  {
   order();
   break;
  }
  case'2':
  {
   notifi();
   break;
  }
  case'3':
  {
   
   stocksearch();
   break;
  }
  default:
  {
   cout<<"INVALID INPUT"<<endl;
  }

 }
 }       


#endif
