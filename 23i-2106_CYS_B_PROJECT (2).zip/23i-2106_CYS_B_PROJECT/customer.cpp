#include "customer.h"


void orderfood()
{
    char head[30], item[50][50];
    double Price[50];
    int No_Items[50];
    int i = 0;

    // Read stock data from file
    fstream fs("stock.txt", ios::in);

    if (!fs)
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    }
    else
    {
        cout << "\nFile Found Congrats";
        fs.getline(head, 30, '\n');

        while (fs.getline(item[i], 50, ' '), fs >> Price[i] >> No_Items[i])
        {
            fs.ignore();
            i++;
        }
        
    }
    int itemCount=i;
    fs.close();
    
        for (int i = 0; i < itemCount - 1; i++) 
	{
          for (int j = 0; j < itemCount - i - 1; j++) 
          {
             if (No_Items[j] > No_Items[j + 1]) 
             {
            // Swap item names
            char tempItem[100]; // assuming a maximum item name length of 100 characters
            strcpy(tempItem, item[j]);
            strcpy(item[j], item[j + 1]);
            strcpy(item[j + 1], tempItem);

            // Swap Prices
            int tempPrice = Price[j];
            Price[j] = Price[j + 1];
            Price[j + 1] = tempPrice;

            // Swap No_Items
            int tempNo_Items = No_Items[j];
            No_Items[j] = No_Items[j + 1];
            No_Items[j + 1] = tempNo_Items;
            }
         }
       }
    // Display menu
    cout << "\n" << head << endl;
    for (int k = 0; k < i; k++)
    {     if (No_Items[k] < 10) 
	        {
                  cout << "\x1b[31m"; // Set text color to red
                } 
                else if (No_Items[k] > 20 && No_Items[k] <= 40) 
                {
                   cout << "\x1b[33m"; // Set text color to yellow
                } 
                else if (No_Items[k] > 40) 
                {
                  cout << "\x1b[32m"; // Set text color to green
                }
        //cout << item[k] << "|" << Price[k] << "|" << No_Items[k] << endl;
         cout << left << setw(15) << item[k] << setw(10) << Price[k] << setw(10) << No_Items[k] << endl;
         cout << "\x1b[0m";
    }

    // Order food
    char choiceitem[50];
    int choice, orderquantity, ordercount;
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);
    
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

    

    if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;

        // Calculate the price
        double total_price = orderquantity * Price[choice - 1];

        // Update stock
        No_Items[choice - 1] -= orderquantity;

        // Write order details to the file
        ofstream order("order.txt", ios::app);
        order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
        order.close();
        
        ///update stock.txt with new data
        ofstream stock("stock.txt");
        stock << head << endl;
        for (int k = 0; k < i; k++)
        {
            stock << item[k] << " " << Price[k] << " " << No_Items[k] << endl;
        }
        stock.close();

        cout << "Order placed successfully." << endl;
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
}




void givecomplain()
{
 
 char complaint[100];

  cin.ignore();  // Clear the input buffer
  cout << "Enter your complaint: ";
  cin.getline(complaint,100);

    // writing the complaint to the file
    
  ofstream complain("complain.txt",ios::app);
    if (complain.is_open()) 
    {
        complain << complaint << endl;
        complain.close();

        cout << "Complaint submitted successfully." << endl;
    } else {
       cout << "Error opening complaints file." << endl;
    }
}





void searchitems()
{
        char head[30], item[10][50];
	double Price[10];
	int No_Items[10];
	int i=0;
	
	fstream fs("stock.txt",ios::in);
               fs.getline(head,30,'\n');
		while(fs.getline(item[i],50,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}
	fs.close();
	
	
  char tobefound[50];
   int flag=0;
    // Clear the input buffer
    cout << "Enter the item name to search: ";
     cin.ignore(); 
    cin.getline(tobefound,50);
      for ( int j = 0; j < i; j++)
       {
          if (strcmp(item[j],tobefound) == 0) 
           {          
            flag=1;
            break;
           }
       }
      
      if (flag==1)
      {
       cout<<"ITEM FOUND"<<endl;
      }
      else
      {
       cout<<"ITEM NOT FOUND"<<endl;
      }
}






void schorder()
{
/////display of menu     
        char head[30], item[50][50];
	double Price[50];
	int No_Items[50];
	int i=0;
	
	fstream fs("stock.txt",ios::in);
	
	if (!fs)//check if file is not available to read
	{
		cout<<"\nFile not found";
		cout<<"\nCheck file name";
	}
	else//file is available for reading now loading data in arrays appropriately
	{
		cout<<"\nFile Found Congrats";
		fs.getline(head,30,'\n');//reading/loading first line of file
		//reading remianing records of file in arrays appropriately
		while(fs.getline(item[i],10,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}							
	}
	
	  int itemCount=i;
	fs.close();
	//now printing data from arrays on screen
	for (int i = 0; i < itemCount - 1; i++) 
	{
          for (int j = 0; j < itemCount - i - 1; j++) 
          {
             if (No_Items[j] > No_Items[j + 1]) 
             {
            // Swap item names
            char tempItem[100]; // assuming a maximum item name length of 100 characters
            strcpy(tempItem, item[j]);
            strcpy(item[j], item[j + 1]);
            strcpy(item[j + 1], tempItem);

            // Swap Prices
            int tempPrice = Price[j];
            Price[j] = Price[j + 1];
            Price[j + 1] = tempPrice;

            // Swap No_Items
            int tempNo_Items = No_Items[j];
            No_Items[j] = No_Items[j + 1];
            No_Items[j + 1] = tempNo_Items;
            }
         }
       }	
	
	cout<<"\n"<<head<<endl;
	for(int k=0;k<i;k++)
	{       if (No_Items[k] < 10) 
	        {
                  cout << "\x1b[31m"; // Set text color to red
                } 
                else if (No_Items[k] > 20 && No_Items[k] <= 40) 
                {
                   cout << "\x1b[33m"; // Set text color to yellow
                } 
                else if (No_Items[k] > 40) 
                {
                  cout << "\x1b[32m"; // Set text color to green
                }
		//cout<<item[k]<<"    |"<<Price[k]<<" |  "<<No_Items[k]<<endl;
		cout << left << setw(15) << item[k] << setw(10) << Price[k] << setw(10) << No_Items[k] << endl;
		cout << "\x1b[0m";
	}
	
/////////////////order scheduled food
    char time[20],choiceitem[50];
    int choice, orderquantity, ordercount;
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;
        
        cout<<"Enter the delivery time::";
        cin.ignore();
        cin.getline(time,20);   
        
        // Calculate the price
        double total_price = orderquantity * Price[choice - 1];

        // Update stock
        No_Items[choice - 1] -= orderquantity;
        
         
        
        // Write order details to the file
        ofstream order("order.txt", ios::app);
        order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price <<"\nDelivery time: "<<time<< "\n\n";
        order.close();
        
        ///update stock.txt with new data
        ofstream stock("stock.txt");
        stock << head << endl;
        for (int k = 0; k < i; k++)
        {
            stock << item[k] << " " << Price[k] << " " << No_Items[k] << endl;
        }
        stock.close();

        cout << "Order placed successfully." << endl;
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
    
   
}




void viewnoti()
{
   ifstream noti("notifications.txt");
    if (noti.is_open()) {
        cout << "Notifications:\n";
        
        char notification[100];
        while (noti.getline(notification, 100)) {
            cout << notification <<endl;
        }
        noti.close();
    } else {
        cout << "Error opening notifications file." << endl;
    }
}

void customer()
{
cout<<"                                   ****************************************"<<endl;
cout<<"                                   *                WELCOME               *"<<endl;
cout<<"                                   *                                      *"<<endl;
cout<<"                                   *               CUSTOMER               *"<<endl;
cout<<"                                   ****************************************"<<endl;
int choice;
 do {
        cout << "Welcome to CDS Online Cafe:\n1. Order Food\n2. Give Complaint\n3. Search Items\n4. Give and Schedule  Order\n5. View Notifications\n6. Exit\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
            {
                orderfood();
                break;
                }

            case 2:
            {
               givecomplain();
                break;
                }

            case 3:
            {
                searchitems();
                break;
                }

            case 4:
            {
                schorder();
                break;
                }

            case 5:
            {
                viewnoti();
                break;
             }
            case 6:{
            
                cout << "Exiting the program.\n";
                break;
              }
            default:
            {
                cout << "Invalid choice. Please try again.\n";
            }
        }
    } while (choice != 6);
}

