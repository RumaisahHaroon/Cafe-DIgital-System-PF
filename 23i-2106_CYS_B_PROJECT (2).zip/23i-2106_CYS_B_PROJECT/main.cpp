#include <iostream>
#include <string.h>
#include<fstream>
#include <iomanip>
using namespace std;
#include "admin.h"
#include "customer.h"
#include "employee.h"
int main()
{

char id;	
cout<<"                                   ****************************************"<<endl;
cout<<"                                   *                WELCOME               *"<<endl;
cout<<"                                   *                  TO                  *"<<endl;
cout<<"                                   *                 CDS                  *"<<endl;
cout<<"                                   ****************************************"<<endl;
cout<<"SELECT WHO YOU ARE::\n1.ADMIN\n2.EMPLOYEE\n3.CUSTOMER\n";
cin>>id;

switch (id)
{
case '1':
{
 admin();
 break;
 //cout<<""<<endl;
}
case '2':
{
 employee();
 
 break;
}
case '3':
{
 customer();
 break;
}
default :
{
 cout<<""<<endl;
 
}

}

	

return 0;

}
