#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "customer.cpp"

void customer();
void orderfood();
void givecomplain();
void searchitems();
void schorder();
void viewnoti();

#endif
